#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/CCKeyboardDispatcher.hpp>
#include <cstdio>
#ifdef GEODE_IS_WINDOWS
#include <windows.h>
#endif

using namespace geode::prelude;

namespace {
    constexpr int OPTIONS[] = {4, 8, 16, 32};
    int s_idx = 0;
    bool s_ownConsole = false;

    struct BtnState {
        bool held = false;     // is the player physically holding jump
        int buffer = 0;        // ticks left in which a landing will trigger a buffered click
        bool firing = false;   // true while we inject our own click
    };
    BtnState s_state[2];       // [0] = player 1, [1] = player 2

    void out(std::string const& msg) {
        if (s_ownConsole) {
            std::printf("[ClickBuffer] %s\n", msg.c_str());
            std::fflush(stdout);
        } else {
            log::info("{}", msg);
        }
    }

    void printMenu() {
        out("================ Predictive Click Buffer ================");
        for (int i = 0; i < 4; i++) {
            out(fmt::format("  {} {} ticks", i == s_idx ? "[x]" : "[ ]", OPTIONS[i]));
        }
        out("  Press F6 to cycle options");
        out("=========================================================");
    }
}

$execute {
#ifdef GEODE_IS_WINDOWS
    // Open our own console if Geode's isn't already showing one.
    if (AllocConsole()) {
        s_ownConsole = true;
        FILE* f;
        freopen_s(&f, "CONOUT$", "w", stdout);
        freopen_s(&f, "CONOUT$", "w", stderr);
        SetConsoleTitleA("Predictive Click Buffer");
    }
#endif
    s_idx = Mod::get()->getSavedValue<int>("tick-index", 0);
    if (s_idx < 0 || s_idx > 3) s_idx = 0;
    printMenu();
}

class $modify(CBKeyboard, CCKeyboardDispatcher) {
    // If this fails to compile on your Geode version, remove the last `double` parameter.
    bool dispatchKeyboardMSG(enumKeyCodes key, bool down, bool repeat, double timestamp) {
        if (down && !repeat && key == KEY_F6) {
            s_idx = (s_idx + 1) % 4;
            Mod::get()->setSavedValue("tick-index", s_idx);
            out(fmt::format("Buffer window set to {} ticks", OPTIONS[s_idx]));
            printMenu();
        }
        return CCKeyboardDispatcher::dispatchKeyboardMSG(key, down, repeat, timestamp);
    }
};

class $modify(CBGameLayer, GJBaseGameLayer) {
    void handleButton(bool down, int button, bool isPlayer1) {
        auto& st = s_state[isPlayer1 ? 0 : 1];

        // Only care about the jump button, and ignore our own injected clicks.
        if (st.firing || button != 1) {
            GJBaseGameLayer::handleButton(down, button, isPlayer1);
            return;
        }

        auto* player = isPlayer1 ? m_player1 : m_player2;
        bool onGround = player && player->m_isOnGround;

        if (down) {
            st.held = true;
            // Click made in the air: remember it so landing within the window re-triggers it.
            if (!onGround) st.buffer = OPTIONS[s_idx];
            out(fmt::format("P{} CLICK DOWN  ({}, buffer={})",
                isPlayer1 ? 1 : 2, onGround ? "ground" : "air", st.buffer));
        } else {
            st.held = false;
            out(fmt::format("P{} CLICK UP", isPlayer1 ? 1 : 2));
        }

        // Always pass the real input through so orbs/pads/portals still work normally.
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
    }

    void processCommands(float dt) {
        GJBaseGameLayer::processCommands(dt);

        for (int i = 0; i < 2; i++) {
            auto& st = s_state[i];
            if (st.buffer <= 0) continue;

            auto* player = i == 0 ? m_player1 : m_player2;
            st.buffer--;

            if (player && player->m_isOnGround) {
                // If still holding, the game already re-jumps on landing by itself.
                // If the player let go early, fire the buffered tap now.
                if (!st.held) {
                    st.firing = true;
                    GJBaseGameLayer::handleButton(true, 1, i == 0);
                    GJBaseGameLayer::handleButton(false, 1, i == 0);
                    st.firing = false;
                    out(fmt::format("P{} BUFFERED CLICK FIRED", i + 1));
                }
                st.buffer = 0;
            }
        }
    }
};
